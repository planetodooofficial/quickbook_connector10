# quickbook_connector10
This is 10th odoo version of quickbook connector
install this package
1-pip install python-quickbooks==0.7.5
2-pip install intuit-oauth